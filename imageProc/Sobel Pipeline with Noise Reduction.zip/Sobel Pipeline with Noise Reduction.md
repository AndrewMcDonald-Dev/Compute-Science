1. Greyscale Reduction
2. Noise Reduction
3. Horinzontal and Vertical Sobel filtering
4. Magnitude Calculation
5. Thresholding


```python
import cv2
import numpy as np
import copy
import matplotlib.pyplot as plt
```

## 1. Greyscale Reduction


```python
# import image
img = cv2.imread("obama.webp")

# Convert to greyscale
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

plt.imshow(img, cmap="gray")
```




    <matplotlib.image.AxesImage at 0x7f6ce808dd50>




    
![png](output_3_1.png)
    


## 2. Gaussian Noise Reduction


```python
# Gaussian filter
gaussian_filter = np.array([[1,2,1],[2,4,2],[1,2,1]], dtype=np.float32) / 16

# Convolve with the image
imgGaussian = cv2.filter2D(img, -1, gaussian_filter)

# Guassian Filter print
plt.imshow(imgGaussian, cmap='gray')
plt.title('Gaussian Filter')
```




    Text(0.5, 1.0, 'Gaussian Filter')




    
![png](output_5_1.png)
    


## 3. Horinzontal and Vertical Sobel Filtering


```python
# Sobel kernels
kernelX = np.array([[1,2,1],[0,0,0],[-1,-2,-1]], dtype=np.float32)
kernelY = np.array([[-1,0,1],[-2,0,2],[-1,0,1]], dtype=np.float32)

# Sobel convolution
imgSobelX = cv2.filter2D(img, cv2.CV_64F, kernelX)
imgSobelY = cv2.filter2D(img, cv2.CV_64F, kernelY)

```

# 4. Magnitude Calculation


```python

Sobel = cv2.magnitude(imgSobelX, imgSobelY)
fig = plt.figure(figsize = (10,10))
# Left image
fig.add_subplot(1,2,1)
plt.imshow(img, cmap='gray')
# Right image
fig.add_subplot(1,2,2)
plt.imshow(Sobel, cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f6ce1736f50>




    
![png](output_9_1.png)
    


# 5. Thresholding


```python
ret,thresh = cv2.threshold(Sobel,160,255,cv2.THRESH_BINARY)
plt.imshow(thresh, cmap="gray")
```




    <matplotlib.image.AxesImage at 0x7f6ce0573ee0>




    
![png](output_11_1.png)
    



```python

```
