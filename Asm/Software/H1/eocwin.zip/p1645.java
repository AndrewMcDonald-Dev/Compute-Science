class X {
   public static void main(String arg[]) 
   {
      int x = 2;
      if (x >= 0)
         x++;
   }
}
