class X {
   public static void main(String arg[]) 
   {
      int a[][];
      a = new int[2][3];
      a[1][2] = 5;
   }
}
