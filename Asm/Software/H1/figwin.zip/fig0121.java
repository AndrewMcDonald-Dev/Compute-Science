class E5 {                                
   public static void main(String[] s)    
   {                                      
      float L, S;                         
      L = 1.0f;       // L is a Large numb
      S = 1E-30f;     // S is a Small numb
      if (L + S == L)                     
         System.out.println("equal");     
      else                                
         System.out.println("not equal"); 
   }                                      
}                                         
