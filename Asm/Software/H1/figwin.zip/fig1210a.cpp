void f(int *p, int x)
{
   int y;
   y = *p + x;
   *p = y;
}
