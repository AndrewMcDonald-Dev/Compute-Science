void simvr(int *p)
{
    int x;
    x = *p;

    body of function--use x instead of *p

    *p = x;
}
