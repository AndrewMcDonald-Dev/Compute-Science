class IRTest {
   public static void main(String arg[]) 
   {
      int y;
      y = sum(1, 2);
   }
   static int sum(int m, int n)
   {
       return m + n;
   }
}
