int m = 5;           // m is a global variable
void fg(int x)       // x is the parameter
{
   int y;            // y is a dynamic local variable
   y = 7;
   x = y + 2;
}
void main()
{
   fg(m);            // m is the argument
}
