void sum(int x, int y)
{
   int z;

   z = x + y;
}
void fk()
{
   sum(5, 10);
}
void main()
{
   sum(5, 10);
   fk();
}
