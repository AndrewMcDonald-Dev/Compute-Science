void sum(int x, int y)
{
   int z;

   z = x + y;
}
void main()
{
   sum(5, 10);
}
