class Div {
   public static void main(String arg[]) 
   {
      System.out.println("Dividend Divisor Quo Rem");
      System.out.println("    7       2     " +  7/2  + "   "  + 7%2);
      System.out.println("   -7       2    "  + -7/2  + "  "   + -7%2);
      System.out.println("    7      -2    "  +  7/-2 + "   "  + 7%-2);
      System.out.println("   -7      -2     " + -7/-2 + "  "   + -7%-2);
   }
}
