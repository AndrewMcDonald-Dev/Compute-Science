void legal()
{           
   int x;   
            
   x = 3;   
            
            
   int y;   
            
   x = 5;   
            
            
            
}           
