class E6 {                            
   public static void main(String[] s)
   {                                  
      float sum = 0.0f;               
      for (int i = 1; i <= 100; i++)  
         sum = sum + 1.0f / i;        
      System.out.print("sum = ");
      System.out.println(sum);
   }                                  
}                                     
