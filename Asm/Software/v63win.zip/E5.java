class E5 {                                
   public static void main(String[] s)    
   {                                      
      double L, S;                         
      L = 1.0;       // L is a Large numb
      S = 1E-30;     // S is a Small numb
      if (L + S == L)                     
         System.out.println("equal");     
      else                                
         System.out.println("not equal"); 
   }                                      
}                                         
