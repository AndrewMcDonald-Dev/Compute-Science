class X {
   static int x;
   public static void main(String arg[]) 
   {   
      x = 1;
      x = 5;
   }
}
