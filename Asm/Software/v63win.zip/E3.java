class E3 {                            
   public static void main(String[] s)
   {                                  
      float x = 0.0f;                 
      while (x != 1.0f)    // infinite loop          
         x = x + 0.1f;
      System.out.print("x =");
      System.out.println(x);
   }                                  
}                                     
