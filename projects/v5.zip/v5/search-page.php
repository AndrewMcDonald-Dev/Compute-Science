<html>

<head>
    <title> Historic Property Information </title>
    <style>
	*{
		background-color: #ffffff;
		margin: 0;
		padding: 0;
		box-sizing: border-box;
		overflow: hidden;
	}
    </style>
</head>

<frameset rows="100, *" frameborder="0" border="0" framespacing="0">
    <frame src="search_form.htm" border="0" name="UP" scrolling="no">
    <frame src="list-search.php" border="0" name="DOWN">
</frameset>

</html>